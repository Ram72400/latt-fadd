subject = "Password reset at {{ $site_name }}"
==
Hi, {{ $staff_name }}

Your password was changed successfully!

If you think this password update was a mistake, reset your password immediately.
==
Hi {{ $staff_name }},

Your password was changed successfully!

If you think this password update was a mistake, reset your password immediately.
