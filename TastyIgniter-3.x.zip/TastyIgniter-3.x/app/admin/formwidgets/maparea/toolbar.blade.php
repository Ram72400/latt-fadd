<div
    class="btn-toolbar justify-content-between"
    data-control="map-toolbar"
    role="toolbar"
>
    <div class="toolbar-item">
        <div class="btn-group">
            <button
                type="button"
                class="btn btn-default"
                data-control="load-area"
            ><i class="fa fa-plus"></i>&nbsp;&nbsp;{{ $prompt ? lang($prompt) : '' }}</button>
        </div>
    </div>
</div>
